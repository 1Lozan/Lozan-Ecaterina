var myApp = angular.module('myApp', []);
myApp.controller('myCtrl',function PostsCtrlAjax($scope, $http) {
    $http.get('storage/clients.json').then(function(response) {
    });
    $scope.clinets = {
            "clients":[]
    }
    $scope.isCopyTable = false;
    $scope.isDate = function(date)
    {
        if(date != undefined && date.length == 10){
            date_split = date.substring(3, 5) + "/" + date.substring(0, 2) + "/" + date.substring(6, 10);
            var d = new Date(date_split);
            $scope.dateValid = angular.isDate(d);
            $scope.dateValid = false;
        }
        else{
            $scope.dateValid = true;
        }
    }
    $scope.registerReq = function(){
            lastId = $scope.clinets.clients.length;

            request = {
                "id":lastId,
                "firstname":$scope.lname, 
                "lastname":$scope.fname,
                "dataBorn":$scope.dataBorn,
                "telefon":$scope.mob,
                "email":$scope.email,
                "preferSalary":$scope.flagPrefSal ? "Negociabil" : $scope.preferSalary,
                "negociabil":$scope.flagPrefSal ? true : false,
                "comment":$scope.comment,
            }
            $scope.clinets.clients.push(request);
            $scope.formJob = true;
        }
        $scope.stergePers = function(id){
            let modified = [];
            angular.forEach($scope.clinets.clients, function(item) {
                if(item.id != id){
                    modified.push(item);
                }
                else{
                    id_car = item.masina_id;
                }
            });
            $scope.clinets.clients = modified;
        }
        
    }
    
);